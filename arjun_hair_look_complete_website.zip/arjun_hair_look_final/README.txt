ARJUN HAIR LOOK WEBSITE

FILES
- index.html: complete responsive website (HTML, CSS and JavaScript included)
- assets/arjun-shop-original.jpg: the original shop photo supplied in chat
- assets/design-reference.png: the selected visual design reference

HOW TO PREVIEW
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, Firefox, or another browser.
3. Keep the assets folder beside index.html so the original shop photo appears.

HOW TO PUBLISH
Upload the complete extracted folder to a static website host (for example Netlify or GitHub Pages). Upload the entire folder, not only index.html.

NOTES
- Call, Google Maps, and Instagram buttons link to the details supplied by the owner.
- The ten service cards are illustrative options; please confirm which services the shop actually offers before publishing them as a definitive menu.
- Haircut inspiration photography and Google Fonts are loaded from external web URLs, so those require an internet connection. The shop photo is included locally.
- This package is a website, not a live published domain. No appointment booking system or online payment is connected.
